import { Component, OnInit, OnChanges } from '@angular/core';

@Component({
  selector: 'app-democomponent',
  templateUrl: './democomponent.component.html',
  styleUrls: ['./democomponent.component.css']
})
export class DemocomponentComponent {
  title: string;
  num: number = 0;
  text: string = "Hello";
  constructor() {
    console.log("constructor")
  }

  Add() {
    this.num = this.num + 1;
  }
}
