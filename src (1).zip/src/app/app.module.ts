import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{ FormsModule, ReactiveFormsModule } from '@angular/forms'

import { Validate } from './reactive-forms/validators'

import { AppComponent } from './app.component';
import { DemocomponentComponent } from './democomponent/democomponent.component';
import { StudentListComponent } from './student-list/student-list.component';
import { StudentSearchComponent } from './student-search/student-search.component';
import { TemplateDrivenComponent } from './template-driven/template-driven.component';
import { ReactiveFormsComponent } from './reactive-forms/reactive-forms.component';

@NgModule({
  declarations: [
    AppComponent,
    DemocomponentComponent,
    StudentListComponent,
    StudentSearchComponent,
    TemplateDrivenComponent,
    ReactiveFormsComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [
    Validate,
  ],
  bootstrap: [StudentListComponent]
})
export class RootModule { }
